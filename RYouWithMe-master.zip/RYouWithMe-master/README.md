# RYouWithMe

Repository for RYouWithMe data. At the moment the only thing here is the Sydney beaches data, and the easiest way to download it is to click on [this link](https://rladiessydney.org/data/sydneybeaches.csv)
